package com.example

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * كلاس الإسقاط وتوليد PDF الملون (A4OverlayPrinter)
 * يقوم بتراكب الطبقات ورسم البيانات المعبأة بدقة عالية على صور الاستمارات الملونة
 */
class A4OverlayPrinter(private val context: Context) {

    companion object {
        const val A4_WIDTH_PTS = 595
        const val A4_HEIGHT_PTS = 842

        // اللون الكحلي الداكن المعتمد للبيانات المعبأة (#001538 / #0F172A)
        val DARK_NAVY_COLOR = Color.parseColor("#001538")
        val SOFT_DARK_COLOR = Color.parseColor("#0F172A")
    }

    private val headerPaint = Paint().apply {
        color = Color.parseColor("#0F172A")
        textSize = 11.0f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val softDarkPaint = Paint().apply {
        color = Color.parseColor("#0F172A")
        textSize = 11f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    private val textPaint = Paint().apply {
        color = DARK_NAVY_COLOR
        textSize = 12.5f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    private val redAccentPaint = Paint().apply {
        color = Color.parseColor("#8B0000") // أحمر داكن للرقم والأرقام الهامة
        textSize = 13f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    /**
     * 1. توليد عقد بيع وشراء العقار بالـ Superimposition
     */
    fun generateRealEstateOverlayPdf(
        backgroundBitmap: Bitmap,
        data: RealEstateContract,
        officeInfo: OfficeInfo = OfficeInfo(SettingsManager.getInstance(context).officeName, SettingsManager.getInstance(context).officePhone, SettingsManager.getInstance(context).officeAddress)
    ): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(A4_WIDTH_PTS, A4_HEIGHT_PTS, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // أ) رسم صورة الخلفية الملونة بكامل مساحة A4
        drawScaledBackground(canvas, backgroundBitmap)
        drawOfficeInfo(canvas, officeInfo, A4_WIDTH_PTS.toFloat(), A4_HEIGHT_PTS.toFloat())

        // ب) إشارات ورسم الحقول
        drawTextField(canvas, data.contractNo, RealEstateCoordinates.contractNo, redAccentPaint)

        // الطرف الأول البائع
        drawTextField(canvas, data.sellerName, RealEstateCoordinates.sellerName)
        drawTextField(canvas, data.sellerAddress, RealEstateCoordinates.sellerAddress)
        drawTextField(canvas, data.sellerIdNumber, RealEstateCoordinates.sellerIdNumber)
        drawTextField(canvas, data.sellerPhone, RealEstateCoordinates.sellerPhone)

        // الطرف الثاني المشتري
        drawTextField(canvas, data.buyerName, RealEstateCoordinates.buyerName)
        drawTextField(canvas, data.buyerAddress, RealEstateCoordinates.buyerAddress)
        drawTextField(canvas, data.buyerIdNumber, RealEstateCoordinates.buyerIdNumber)
        drawTextField(canvas, data.buyerPhone, RealEstateCoordinates.buyerPhone)

        // تفاصيل العقار والبنود
        drawTextField(canvas, data.propertyType, RealEstateCoordinates.propertyType)
        drawTextField(canvas, "${data.propertyArea} م²", RealEstateCoordinates.propertyArea)
        drawTextField(canvas, data.plotSequenceNo, RealEstateCoordinates.plotSequenceNo)
        drawTextField(canvas, data.neighborhood, RealEstateCoordinates.neighborhood)

        drawTextField(canvas, "${data.totalPrice} دينار", RealEstateCoordinates.totalPrice)
        drawTextField(canvas, "${data.depositPrice} دينار", RealEstateCoordinates.depositPrice)
        drawTextField(canvas, "${data.remainingPrice} دينار", RealEstateCoordinates.remainingPrice)

        drawTextField(canvas, "مبلغ التعويض الاتفاقي", RealEstateCoordinates.sellerPenalty)
        drawTextField(canvas, "مبلغ التضمين الاتفاقي", RealEstateCoordinates.buyerPenalty)

        drawTextField(canvas, data.contractDate, RealEstateCoordinates.contractDate)
        drawTextField(canvas, data.additionalNotes, RealEstateCoordinates.additionalNotes)

        // التواقيع
        drawTextField(canvas, data.sellerName, RealEstateCoordinates.sellerSignature)
        drawTextField(canvas, data.witness1Name, RealEstateCoordinates.witness1Signature)
        drawTextField(canvas, data.witness2Name, RealEstateCoordinates.witness2Signature)
        drawTextField(canvas, data.buyerName, RealEstateCoordinates.buyerSignature)

        pdfDocument.finishPage(page)
        val outputFile = getOutputPdfFile("RealEstate_Contract_${data.contractNo}.pdf")
        writePdfToFile(pdfDocument, outputFile)
        return outputFile
    }

    /**
     * 2. توليد عقد بيع سيارة بالـ Superimposition
     */
    fun generateCarSaleOverlayPdf(
        backgroundBitmap: Bitmap,
        data: CarSaleContract,
        officeInfo: OfficeInfo = OfficeInfo(SettingsManager.getInstance(context).officeName, SettingsManager.getInstance(context).officePhone, SettingsManager.getInstance(context).officeAddress)
    ): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(A4_WIDTH_PTS, A4_HEIGHT_PTS, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        drawScaledBackground(canvas, backgroundBitmap)
        drawOfficeInfo(canvas, officeInfo, A4_WIDTH_PTS.toFloat(), A4_HEIGHT_PTS.toFloat())

        drawTextField(canvas, data.contractNo, CarSaleCoordinates.contractNo, redAccentPaint)
        drawTextField(canvas, data.carLegalOwner, CarSaleCoordinates.carLegalOwner)
        drawTextField(canvas, data.ownerAddress, CarSaleCoordinates.ownerAddress)

        // البائع
        drawTextField(canvas, data.sellerName, CarSaleCoordinates.sellerName)
        drawTextField(canvas, data.sellerAddress, CarSaleCoordinates.sellerAddress)
        drawTextField(canvas, data.sellerIdNumber, CarSaleCoordinates.sellerIdNumber)
        drawTextField(canvas, data.sellerPhone, CarSaleCoordinates.sellerPhone)

        // المشتري
        drawTextField(canvas, data.buyerName, CarSaleCoordinates.buyerName)
        drawTextField(canvas, data.buyerAddress, CarSaleCoordinates.buyerAddress)
        drawTextField(canvas, data.buyerIdNumber, CarSaleCoordinates.buyerIdNumber)
        drawTextField(canvas, data.buyerPhone, CarSaleCoordinates.buyerPhone)

        // مواصفات السيارة
        drawTextField(canvas, "${data.annualRegNumber} (${data.carCategory})", CarSaleCoordinates.annualRegHeader)
        drawTextField(canvas, data.carBrandAndType, CarSaleCoordinates.carBrandAndType)
        drawTextField(canvas, data.modelYear, CarSaleCoordinates.modelYear)
        drawTextField(canvas, data.color, CarSaleCoordinates.color)
        drawTextField(canvas, data.annualRegNumber, CarSaleCoordinates.annualRegNumber)
        drawTextField(canvas, data.engineNumber, CarSaleCoordinates.engineNumber)
        drawTextField(canvas, data.chassisNumber, CarSaleCoordinates.chassisNumber)

        drawTextField(canvas, "${data.totalPrice} دينار", CarSaleCoordinates.totalPrice)
        drawTextField(canvas, data.totalPriceWords, CarSaleCoordinates.totalPriceWords)
        drawTextField(canvas, "${data.paidAmount} دينار", CarSaleCoordinates.paidAmount)
        drawTextField(canvas, "${data.remainingAmount} دينار", CarSaleCoordinates.remainingAmount)

        drawTextField(canvas, data.contractDate, CarSaleCoordinates.contractDate)

        // التواقيع
        drawTextField(canvas, data.sellerName, CarSaleCoordinates.sellerSignature)
        drawTextField(canvas, data.witnessName, CarSaleCoordinates.witnessSignature)
        drawTextField(canvas, data.organizerName, CarSaleCoordinates.organizerSignature)
        drawTextField(canvas, data.buyerName, CarSaleCoordinates.buyerSignature)

        pdfDocument.finishPage(page)
        val outputFile = getOutputPdfFile("CarSale_Contract_${data.contractNo}.pdf")
        writePdfToFile(pdfDocument, outputFile)
        return outputFile
    }

    /**
     * 3. توليد عقد إيجار بالـ Superimposition
     */
    fun generateRentalOverlayPdf(
        backgroundBitmap: Bitmap,
        data: RentalContract,
        officeInfo: OfficeInfo = OfficeInfo(SettingsManager.getInstance(context).officeName, SettingsManager.getInstance(context).officePhone, SettingsManager.getInstance(context).officeAddress)
    ): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(A4_WIDTH_PTS, A4_HEIGHT_PTS, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        drawScaledBackground(canvas, backgroundBitmap)
        drawOfficeInfo(canvas, officeInfo, A4_WIDTH_PTS.toFloat(), A4_HEIGHT_PTS.toFloat())

        drawTextField(canvas, data.contractNo, RentalCoordinates.contractNo, redAccentPaint)
        drawTextField(canvas, data.sequenceNumber, RentalCoordinates.sequenceNumber)
        drawTextField(canvas, data.doorsNumber, RentalCoordinates.doorsNumber)

        drawTextField(canvas, data.lessorName, RentalCoordinates.lessorName)
        drawTextField(canvas, data.lesseeName, RentalCoordinates.lesseeName)

        drawTextField(canvas, data.propertyLocation, RentalCoordinates.propertyLocation)
        drawTextField(canvas, data.neighborhood, RentalCoordinates.neighborhood)
        drawTextField(canvas, data.alleyNumber, RentalCoordinates.alleyNumber)
        drawTextField(canvas, data.leaseDuration, RentalCoordinates.leaseDuration)

        drawTextField(canvas, data.startDate, RentalCoordinates.startDate)
        drawTextField(canvas, data.endDate, RentalCoordinates.endDate)

        drawTextField(canvas, data.rentAmountWords, RentalCoordinates.rentAmountWords)
        drawTextField(canvas, "${data.rentAmountNumber} دينار", RentalCoordinates.rentAmountNumber)

        drawTextField(canvas, data.signDate, RentalCoordinates.signDate)
        drawTextField(canvas, data.additionalClauses, RentalCoordinates.additionalClauses)

        // التواقيع
        drawTextField(canvas, data.lessorName, RentalCoordinates.lessorSignature)
        drawTextField(canvas, data.lesseeName, RentalCoordinates.lesseeSignature)
        drawTextField(canvas, data.witness1Name, RentalCoordinates.witness1Signature)
        drawTextField(canvas, data.witness2Name, RentalCoordinates.witness2Signature)

        pdfDocument.finishPage(page)
        val outputFile = getOutputPdfFile("Rental_Contract_${data.contractNo}.pdf")
        writePdfToFile(pdfDocument, outputFile)
        return outputFile
    }

    /**
     * 4. توليد عقد بيع وشراء الدراجات والتكتك والستوتات بالـ Superimposition
     */
    fun generateMotorcycleOverlayPdf(
        backgroundBitmap: Bitmap,
        data: MotorcycleContract,
        officeInfo: OfficeInfo = OfficeInfo(SettingsManager.getInstance(context).officeName, SettingsManager.getInstance(context).officePhone, SettingsManager.getInstance(context).officeAddress)
    ): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(A4_WIDTH_PTS, A4_HEIGHT_PTS, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        drawScaledBackground(canvas, backgroundBitmap)
        drawOfficeInfo(canvas, officeInfo, A4_WIDTH_PTS.toFloat(), A4_HEIGHT_PTS.toFloat())

        // رقم العقد الهيدر
        drawTextField(canvas, data.contractNo, MotorcycleCoordinates.contractNo, redAccentPaint)

        // الطرف الأول (البائع)
        drawTextField(canvas, data.sellerName, MotorcycleCoordinates.sellerName, softDarkPaint)
        drawTextField(canvas, data.sellerAddress, MotorcycleCoordinates.sellerAddress, softDarkPaint)
        drawTextField(canvas, data.sellerNeighborhood, MotorcycleCoordinates.sellerNeighborhood, softDarkPaint)
        drawTextField(canvas, data.sellerAlley, MotorcycleCoordinates.sellerAlley, softDarkPaint)
        drawTextField(canvas, data.sellerHouse, MotorcycleCoordinates.sellerHouse, softDarkPaint)
        drawTextField(canvas, data.sellerIdNumber, MotorcycleCoordinates.sellerIdNumber, softDarkPaint)
        drawTextField(canvas, data.sellerIdIssueDate, MotorcycleCoordinates.sellerIdIssueDate, softDarkPaint)
        drawTextField(canvas, data.sellerRegistry, MotorcycleCoordinates.sellerRegistry, softDarkPaint)
        drawTextField(canvas, data.sellerPhone, MotorcycleCoordinates.sellerPhone, softDarkPaint)

        // الطرف الثاني (المشتري)
        drawTextField(canvas, data.buyerName, MotorcycleCoordinates.buyerName, softDarkPaint)
        drawTextField(canvas, data.buyerAddress, MotorcycleCoordinates.buyerAddress, softDarkPaint)
        drawTextField(canvas, data.buyerNeighborhood, MotorcycleCoordinates.buyerNeighborhood, softDarkPaint)
        drawTextField(canvas, data.buyerAlley, MotorcycleCoordinates.buyerAlley, softDarkPaint)
        drawTextField(canvas, data.buyerHouse, MotorcycleCoordinates.buyerHouse, softDarkPaint)
        drawTextField(canvas, data.buyerIdNumber, MotorcycleCoordinates.buyerIdNumber, softDarkPaint)
        drawTextField(canvas, data.buyerIdIssueDate, MotorcycleCoordinates.buyerIdIssueDate, softDarkPaint)
        drawTextField(canvas, data.buyerRegistry, MotorcycleCoordinates.buyerRegistry, softDarkPaint)
        drawTextField(canvas, data.buyerPhone, MotorcycleCoordinates.buyerPhone, softDarkPaint)

        // مواصفات المركبة / الدراجة
        drawTextField(canvas, data.registeredNumber, MotorcycleCoordinates.registeredNumber, softDarkPaint)
        drawTextField(canvas, data.vehicleType, MotorcycleCoordinates.vehicleType, softDarkPaint)
        drawTextField(canvas, data.contactPhone, MotorcycleCoordinates.contactPhone, softDarkPaint)

        drawTextField(canvas, data.color, MotorcycleCoordinates.color, softDarkPaint)
        drawTextField(canvas, data.engineCc, MotorcycleCoordinates.engineCc, softDarkPaint)
        drawTextField(canvas, data.brand, MotorcycleCoordinates.brand, softDarkPaint)
        drawTextField(canvas, data.engineNumber, MotorcycleCoordinates.engineNumber, softDarkPaint)

        drawTextField(canvas, data.chassisNumber, MotorcycleCoordinates.chassisNumber, softDarkPaint)

        // المبالغ المالية
        drawTextField(canvas, if (data.totalPrice.isNotBlank()) "${data.totalPrice} دينار" else "", MotorcycleCoordinates.totalPrice, softDarkPaint)
        drawTextField(canvas, if (data.paidAmount.isNotBlank()) "${data.paidAmount} دينار" else "", MotorcycleCoordinates.paidAmount, softDarkPaint)
        drawTextField(canvas, if (data.remainingAmount.isNotBlank()) "${data.remainingAmount} دينار" else "", MotorcycleCoordinates.remainingAmount, softDarkPaint)

        // البائع الحائز
        drawTextField(canvas, data.possessorName, MotorcycleCoordinates.possessorName, softDarkPaint)
        drawTextField(canvas, data.possessorAddress, MotorcycleCoordinates.possessorAddress, softDarkPaint)
        drawTextField(canvas, data.possessorNeighborhood, MotorcycleCoordinates.possessorNeighborhood, softDarkPaint)
        drawTextField(canvas, data.possessorAlley, MotorcycleCoordinates.possessorAlley, softDarkPaint)
        drawTextField(canvas, data.possessorHouse, MotorcycleCoordinates.possessorHouse, softDarkPaint)
        drawTextField(canvas, data.possessorPhone, MotorcycleCoordinates.possessorPhone, softDarkPaint)
        drawTextField(canvas, data.possessorIdNumber, MotorcycleCoordinates.possessorIdNumber, softDarkPaint)

        // الملاحظات والتاريخ والوقت
        drawTextField(canvas, data.notes, MotorcycleCoordinates.notes, softDarkPaint)
        drawTextField(canvas, data.contractDate, MotorcycleCoordinates.contractDate, softDarkPaint)
        drawTextField(canvas, data.contractTime, MotorcycleCoordinates.contractTime, softDarkPaint)

        // التواقيع
        drawTextField(canvas, data.sellerName, MotorcycleCoordinates.sellerSignature, softDarkPaint)
        drawTextField(canvas, data.witnessName, MotorcycleCoordinates.witnessSignature, softDarkPaint)
        drawTextField(canvas, data.buyerName, MotorcycleCoordinates.buyerSignature, softDarkPaint)

        pdfDocument.finishPage(page)
        val outputFile = getOutputPdfFile("Motorcycle_Contract_${data.contractNo}.pdf")
        writePdfToFile(pdfDocument, outputFile)
        return outputFile
    }

    /**
     * إسقاط اسم المكتب ورقم الهاتف المحفوظين ديناميكياً في ترويسة أعلى الاستمارة (Header Area)
     * باستخدام الإحداثيات (X, Y) في منتصف أعلى صفحة الـ A4
     */
    private fun drawOfficeHeader(canvas: Canvas) {
        val settingsManager = SettingsManager.getInstance(context)
        val name = settingsManager.officeName
        val phone = settingsManager.officePhone

        if (name.isNotBlank() || phone.isNotBlank()) {
            val headerText = buildString {
                if (name.isNotBlank()) append(name)
                if (phone.isNotBlank()) {
                    if (isNotEmpty()) append("  |  هاتف: ")
                    append(phone)
                }
            }
            // إحداثيات (X, Y) في منتصف أعلى صفحة A4 (عرض 595pt -> منتصف 297.5pt, Y = 28pt)
            canvas.drawText(headerText, 297.5f, 28f, headerPaint)
        }
    }

    /**
     * رسم خلفية العقد الملونة بحجم الصفحة بالضبط (595x842 pt)
     */
    private fun drawScaledBackground(canvas: Canvas, bitmap: Bitmap) {
        val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
        val destRect = RectF(0f, 0f, A4_WIDTH_PTS.toFloat(), A4_HEIGHT_PTS.toFloat())
        canvas.drawBitmap(bitmap, srcRect, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
    }

    /**
     * رسم النص المعبأ في الإحداثيات المحددة بدقة
     */
    private fun drawTextField(
        canvas: Canvas,
        text: String,
        point: Point2D,
        paint: Paint = textPaint
    ) {
        if (text.isNotBlank()) {
            canvas.drawText(text, point.x, point.y, paint)
        }
    }

    private fun getOutputPdfFile(filename: String): File {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
        if (!dir.exists()) dir.mkdirs()
        return File(dir, filename)
    }

    private fun writePdfToFile(pdfDocument: PdfDocument, file: File) {
        var outputStream: FileOutputStream? = null
        try {
            outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
        } catch (e: IOException) {
            e.printStackTrace()
        } finally {
            outputStream?.close()
            pdfDocument.close()
        }
    }
}
