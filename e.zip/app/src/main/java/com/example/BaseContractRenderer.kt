package com.example

import android.content.Context
import android.graphics.*
import androidx.annotation.ColorInt

/**
 * BaseContractRenderer: المكون الأساسي الموحد لجميع محركات رسم العقود الرسمية على ورقة A4.
 * يطبق مبادئ Clean Architecture و DRY لمنع تكرار كود الرسم، ويضمن:
 * 1. قياسات دقيقة ثابتة مبنية على حجم ورقة A4 القياسية (1240x1754 بكسل).
 * 2. محاذاة RTL عربية صحيحة 100%.
 * 3. تصغير تلقائي لخط النص عند تجاوز الحدود المخصصة لمنع التداخل أو الخروج عن الصفحة.
 * 4. دعم تحميل الصور والأيقونات الاختيارية من مجلد Assets أو Drawables بأمان وبدون فراغات عند غيابها.
 * 5. رسم حقول العقود، البنود القانونية، والتواقيع بمرونة تامة.
 */
abstract class BaseContractRenderer {

    companion object {
        const val A4_WIDTH = 1240f
        const val A4_HEIGHT = 1754f

        // الألوان الموحدة
        @ColorInt val COLOR_PRIMARY = Color.parseColor("#0F172A")    // كحلي فاخر
        @ColorInt val COLOR_SECONDARY = Color.parseColor("#1E3A8A")  // أزرق ملكي
        @ColorInt val COLOR_TEXT = Color.parseColor("#0F172A")       // أسود النص
        @ColorInt val COLOR_LABEL = Color.parseColor("#334155")      // رمادي التسميات
        @ColorInt val COLOR_BORDER = Color.parseColor("#94A3B8")     // إطار العقد
        @ColorInt val COLOR_BG_LIGHT = Color.parseColor("#F8FAFC")   // خلفيات المربعات
        @ColorInt val COLOR_RED_ACCENT = Color.parseColor("#991B1B") // لون الأرقام المميزة
    }

    // فرُش الرسم الجاهزة للأداء العالي
    protected val framePaint = Paint().apply {
        color = COLOR_PRIMARY
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
        isAntiAlias = true
    }

    protected val innerFramePaint = Paint().apply {
        color = COLOR_BORDER
        style = Paint.Style.STROKE
        strokeWidth = 1f
        isAntiAlias = true
    }

    protected val titlePaint = Paint().apply {
        color = COLOR_PRIMARY
        textSize = 34f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    protected val subtitlePaint = Paint().apply {
        color = COLOR_LABEL
        textSize = 20f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    protected val labelPaint = Paint().apply {
        color = COLOR_LABEL
        textSize = 18f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val valuePaint = Paint().apply {
        color = COLOR_TEXT
        textSize = 18f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val bodyTextPaint = Paint().apply {
        color = COLOR_TEXT
        textSize = 17f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val dotPaint = Paint().apply {
        color = COLOR_BORDER
        textSize = 16f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    /**
     * الدالة المفتاحية لتوليد صورة العقد (A4 Bitmap)
     */
    fun renderBitmap(
        contractData: Any,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(A4_WIDTH.toInt(), A4_HEIGHT.toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        // 1. إطار ورقة A4 المزدوج
        drawA4Borders(canvas)

        // 2. التنفيذ الخاص برسم العقد حسب الفئة الابنة
        drawContractContent(canvas, contractData, officeInfo, context)

        return bitmap
    }

    /**
     * دالة رسم الإطار الخارجي المزدوج الفاخر
     */
    protected open fun drawA4Borders(canvas: Canvas) {
        val outerMargin = 35f
        val innerMargin = 40f
        val outerRect = RectF(outerMargin, outerMargin, A4_WIDTH - outerMargin, A4_HEIGHT - outerMargin)
        val innerRect = RectF(innerMargin, innerMargin, A4_WIDTH - innerMargin, A4_HEIGHT - innerMargin)

        canvas.drawRoundRect(outerRect, 12f, 12f, framePaint)
        canvas.drawRoundRect(innerRect, 10f, 10f, innerFramePaint)
    }

    /**
     * دالة مجردة (Abstract) تحتوي على خطوات رسم محتوى العقد المحدد
     */
    protected abstract fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    )

    /**
     * رسم نص RTL مع ضبط دقيق يمنع الخروج عن الشاشة أو التداخل
     */
    protected fun drawRtlText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        paint: Paint = valuePaint,
        align: Paint.Align = Paint.Align.RIGHT
    ) {
        if (text.isEmpty()) return

        val originalSize = paint.textSize
        val currentPaint = Paint(paint).apply { textAlign = align }

        var measureWidth = currentPaint.measureText(text)
        while (measureWidth > maxWidth && currentPaint.textSize > 10f) {
            currentPaint.textSize -= 1f
            measureWidth = currentPaint.measureText(text)
        }

        canvas.drawText(text, x, y, currentPaint)
        paint.textSize = originalSize // إعادة تعيين الحجم الأصلي
    }

    /**
     * رسم حقل نصي يتضمن عنواناً ونصف فارغ منقوطاً مع قيمة النص فوق النقاط
     */
    protected fun drawFieldWithDots(
        canvas: Canvas,
        label: String,
        value: String,
        x: Float,
        y: Float,
        totalWidth: Float,
        labelWidth: Float = 0f
    ) {
        // 1. رسم عنوان الحقل
        var currentX = x
        if (label.isNotEmpty()) {
            labelPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(label, currentX, y, labelPaint)
            val computedLabelWidth = if (labelWidth > 0f) labelWidth else labelPaint.measureText(label) + 10f
            currentX -= computedLabelWidth
        }

        val dotSpaceWidth = (currentX - (x - totalWidth)).coerceAtLeast(30f)

        // 2. إذا كان القيمة فارغة: رسم نقاط إكمال
        if (value.isBlank()) {
            val dots = buildString {
                repeat((dotSpaceWidth / 7f).toInt().coerceAtLeast(4)) { append(".") }
            }
            dotPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(dots, currentX, y, dotPaint)
        } else {
            // 3. رسم القيمة المدخلة مع تقليص تلقائي عند زيادة الطول
            drawRtlText(
                canvas = canvas,
                text = value,
                x = currentX,
                y = y,
                maxWidth = dotSpaceWidth,
                paint = valuePaint,
                align = Paint.Align.RIGHT
            )
        }
    }

    /**
     * رسم مربعين متجاورين (الطرف الأول البائع - الطرف الثاني المشتري) بتصميم رسمي فاخر
     */
    protected fun drawSideBySidePartyBoxes(
        canvas: Canvas,
        topY: Float,
        boxHeight: Float,
        rightTitle: String,
        leftTitle: String
    ): Pair<RectF, RectF> {
        val margin = 50f
        val boxWidth = (A4_WIDTH - (margin * 2) - 30f) / 2f

        val rightBox = RectF(A4_WIDTH - margin - boxWidth, topY, A4_WIDTH - margin, topY + boxHeight)
        val leftBox = RectF(margin, topY, margin + boxWidth, topY + boxHeight)

        val bgPaint = Paint().apply {
            color = COLOR_BG_LIGHT
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val borderPaint = Paint().apply {
            color = COLOR_PRIMARY
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        val headerBgPaint = Paint().apply {
            color = COLOR_PRIMARY
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val headerHeight = 36f

        // رسم المربع الأيمن
        canvas.drawRoundRect(rightBox, 10f, 10f, bgPaint)
        val rightHeaderRect = RectF(rightBox.left, rightBox.top, rightBox.right, rightBox.top + headerHeight)
        val rightPath = Path().apply {
            addRoundRect(rightHeaderRect, floatArrayOf(10f, 10f, 10f, 10f, 0f, 0f, 0f, 0f), Path.Direction.CW)
        }
        canvas.drawPath(rightPath, headerBgPaint)
        canvas.drawRoundRect(rightBox, 10f, 10f, borderPaint)

        // رسم المربع الأيسر
        canvas.drawRoundRect(leftBox, 10f, 10f, bgPaint)
        val leftHeaderRect = RectF(leftBox.left, leftBox.top, leftBox.right, leftBox.top + headerHeight)
        val leftPath = Path().apply {
            addRoundRect(leftHeaderRect, floatArrayOf(10f, 10f, 10f, 10f, 0f, 0f, 0f, 0f), Path.Direction.CW)
        }
        canvas.drawPath(leftPath, headerBgPaint)
        canvas.drawRoundRect(leftBox, 10f, 10f, borderPaint)

        // رسم عناوين المربعين بالنص الأبيض الناصع
        val headerPaint = Paint().apply {
            color = Color.WHITE
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText(rightTitle, rightBox.centerX(), topY + 25f, headerPaint)
        canvas.drawText(leftTitle, leftBox.centerX(), topY + 25f, headerPaint)

        return Pair(rightBox, leftBox)
    }

    /**
     * رسم صورة هيدر اختيارية بأمان، إذا لم توجد يتم تجاهلها دون أخطاء أو فراغات.
     */
    protected fun drawOptionalHeaderImage(
        canvas: Canvas,
        context: Context?,
        assetOrDrawableName: String,
        destRect: RectF
    ) {
        if (context == null) return
        try {
            // محاولة تحميل الصورة من drawables
            val resId = context.resources.getIdentifier(assetOrDrawableName, "drawable", context.packageName)
            if (resId != 0) {
                val bitmap = BitmapFactory.decodeResource(context.resources, resId)
                if (bitmap != null) {
                    canvas.drawBitmap(bitmap, null, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
                    return
                }
            }

            // محاولة تحميل الصورة من assets
            val inputStream = context.assets.open(assetOrDrawableName)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            if (bitmap != null) {
                canvas.drawBitmap(bitmap, null, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
            }
        } catch (_: Exception) {
            // تجاهل أي خطأ بهدوء وبدون أي تأثير على الرسم
        }
    }

    /**
     * رسم التواقيع أسفل العقد بالتوزيع المتساوي
     */
    protected fun drawSignatures(
        canvas: Canvas,
        titles: List<String>,
        bottomY: Float = A4_HEIGHT - 185f
    ) {
        val margin = 50f
        val totalWidth = A4_WIDTH - (margin * 2)
        val colWidth = totalWidth / titles.size.coerceAtLeast(1)

        val sigPaint = Paint().apply {
            color = COLOR_PRIMARY
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val dotLinePaint = Paint().apply {
            color = COLOR_BORDER
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        for (i in titles.indices) {
            val centerX = A4_WIDTH - margin - (i * colWidth) - (colWidth / 2f)
            canvas.drawText("...........................", centerX, bottomY - 25f, dotLinePaint)
            canvas.drawText(titles[i], centerX, bottomY, sigPaint)
        }
    }
}
