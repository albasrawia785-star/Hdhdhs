package com.example

/**
 * نموذج موحد لهيكلة استمارة العقد A4 (Clean Domain Model)
 * يسمح برسم جميع أنواع العقود بأسلوب ديناميكي موحد مرن خالٍ من التكرار.
 */
data class ContractFormModel(
    val contractType: ContractType,
    val title: String,
    val contractNo: String,
    val contractDate: String,
    val sections: List<ContractSection>,
    val clauses: List<String> = emptyList(),
    val signatures: List<String>
)

data class ContractSection(
    val title: String,
    val rows: List<ContractRow>
)

data class ContractRow(
    val items: List<ContractField>
)

data class ContractField(
    val label: String,
    val value: String,
    val weight: Float = 1f,
    val isHighlight: Boolean = false
)
