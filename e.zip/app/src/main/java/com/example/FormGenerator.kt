package com.example

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

/**
 * FormGenerator: المحرك الموحد الأساسي لرسم ومعاينة وطباعة كافة استمارات العقود الـ A4
 *
 * يعتمد على معمارية Clean Architecture بواسطة ContractTemplateManager ورسامات العقود (BaseContractRenderer):
 * - رسم احترافي عالي الجودة مطابق للصورة الأصلية تماماً لكل عقد.
 * - توزيع حركي متناسب يضمن استغلال كامل ورقة الـ A4 بدون فراغات بيضاء كبيرة أو ازدحام.
 * - مطابقة 100% بين المعاينة والطباعة الـ PDF.
 * - أداء عالي ودعم إضافة أي أنواع عقود جديدة تلقائياً.
 */
object FormGenerator {

    const val A4_WIDTH = 1240
    const val A4_HEIGHT = 1754

    /**
     * 1. إنشاء صورة A4 لعقد بيع وشراء العقارات
     */
    fun renderRealEstateContractBitmap(
        data: RealEstateContract,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        return ContractTemplateManager.renderContractBitmap(ContractType.REAL_ESTATE, data, officeInfo, context)
    }

    /**
     * 2. إنشاء صورة A4 لعقد بيع وشراء السيارات
     */
    fun renderCarSaleContractBitmap(
        data: CarSaleContract,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        return ContractTemplateManager.renderContractBitmap(ContractType.CAR_SALE, data, officeInfo, context)
    }

    /**
     * 3. إنشاء صورة A4 لعقد إيجار الدور والأراضي
     */
    fun renderRentalContractBitmap(
        data: RentalContract,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        return ContractTemplateManager.renderContractBitmap(ContractType.RENTAL, data, officeInfo, context)
    }

    /**
     * 4. إنشاء صورة A4 لعقد بيع وشراء الدراجات والتكتك والستوتات
     */
    fun renderMotorcycleContractBitmap(
        data: MotorcycleContract,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        return ContractTemplateManager.renderContractBitmap(ContractType.MOTORCYCLE, data, officeInfo, context)
    }

    /**
     * دالة عامة موحدة لتوليد صورة أي عقد (Bitmap) حسب نوعه وبياناته
     */
    fun renderContractBitmap(
        contractData: Any,
        contractType: ContractType,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        return ContractTemplateManager.renderContractBitmap(contractType, contractData, officeInfo, context)
    }

    /**
     * تحويل صورة Bitmap إلى ملف PDF عالي الجودة للطباعة والتصدير
     */
    fun generatePdfFromBitmap(bitmap: Bitmap, context: Context, fileName: String = "contract_print.pdf"): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
        val destRect = Rect(0, 0, 595, 842)
        canvas.drawBitmap(bitmap, srcRect, destRect, Paint(Paint.FILTER_BITMAP_FLAG))

        pdfDocument.finishPage(page)

        val outputFile = File(context.cacheDir, fileName)
        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        return outputFile
    }

    /**
     * توليد وحفظ ملف PDF للعقد تلقائياً باقتطاع ومحاذاة مثالية
     */
    fun generateContractPdf(
        contractData: Any,
        contractType: ContractType,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context
    ): File {
        val bitmap = renderContractBitmap(contractData, contractType, officeInfo, context)
        return generatePdfFromBitmap(bitmap, context, "contract_${contractType.name.lowercase()}.pdf")
    }

    /**
     * طباعة مستند A4 مباشرة عبر Android PrintManager (طباعة النظام والـ PDF)
     */
    fun printViaAndroidPrintManager(context: Context, bitmap: Bitmap, jobName: String = "عقد A4 رسمي") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? android.print.PrintManager ?: return

        printManager.print(
            jobName,
            object : android.print.PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: android.print.PrintAttributes?,
                    newAttributes: android.print.PrintAttributes?,
                    cancellationSignal: android.os.CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: android.os.Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val info = android.print.PrintDocumentInfo.Builder("$jobName.pdf")
                        .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(1)
                        .build()
                    callback?.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out android.print.PageRange>?,
                    destination: android.os.ParcelFileDescriptor?,
                    cancellationSignal: android.os.CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    val pdfDocument = PdfDocument()
                    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
                    val page = pdfDocument.startPage(pageInfo)

                    val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
                    val destRect = Rect(0, 0, 595, 842)
                    page.canvas.drawBitmap(bitmap, srcRect, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
                    pdfDocument.finishPage(page)

                    try {
                        FileOutputStream(destination?.fileDescriptor).use { out ->
                            pdfDocument.writeTo(out)
                        }
                        callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    } finally {
                        pdfDocument.close()
                    }
                }
            },
            android.print.PrintAttributes.Builder()
                .setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4)
                .build()
        )
    }
}
