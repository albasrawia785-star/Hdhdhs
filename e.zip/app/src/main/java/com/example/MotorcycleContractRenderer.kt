package com.example

import android.content.Context
import android.graphics.*

/**
 * MotorcycleContractRenderer: محرك رسم عقد بيع وشراء الدراجات والتكتك والستوتات
 * مطابق 100% للتصميم العراقي الرسمي المعتمد في المعارض والمكاتب الرسمية.
 */
class MotorcycleContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? MotorcycleContract ?: MotorcycleContract()

        val margin = 40f
        val fullWidth = A4_WIDTH - (margin * 2)

        val greenPrimary = Color.parseColor("#047857")
        val greenLightBg = Color.parseColor("#F0FDF4")
        val redAccent = Color.parseColor("#D32F2F")
        val darkText = Color.parseColor("#1E293B")
        val borderGray = Color.parseColor("#CBD5E1")

        // ==================== 1. الترويسة الهيدر العلوي ====================
        // أ) مربع رقم العقد (أعلى اليمين)
        val noBoxRect = RectF(A4_WIDTH - margin - 220f, 45f, A4_WIDTH - margin, 125f)
        val noBoxBorder = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        val noBoxBg = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(noBoxRect, 10f, 10f, noBoxBg)
        canvas.drawRoundRect(noBoxRect, 10f, 10f, noBoxBorder)

        val noHeaderPaint = Paint().apply {
            color = darkText
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val noValPaint = Paint().apply {
            color = redAccent
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("رقم العقد", noBoxRect.centerX(), 72f, noHeaderPaint)
        canvas.drawText("№  ${data.contractNo.ifEmpty { "004126" }}", noBoxRect.centerX(), 108f, noValPaint)


        // ب) ترويسة اسم المعرض والشعار (المنتصف)
        val galleryName = officeInfo.officeName.ifEmpty { "معرض السلام للدراجات والتكتك" }
        val galleryNamePaint = Paint().apply {
            color = greenPrimary
            textSize = 36f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(galleryName, A4_WIDTH / 2f, 80f, galleryNamePaint)

        // شريط أحمر خلف عبارة الوصف
        val pillRect = RectF(A4_WIDTH / 2f - 160f, 95f, A4_WIDTH / 2f + 160f, 125f)
        val pillBg = Paint().apply {
            color = redAccent
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(pillRect, 15f, 15f, pillBg)

        val pillTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("لتجارة الدراجات والتكتك والستوتات", A4_WIDTH / 2f, 117f, pillTextPaint)

        // عنوان العقد
        val mainTitlePaint = Paint().apply {
            color = darkText
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("عقد بيع وشراء الدراجات والتكتك", A4_WIDTH / 2f, 158f, mainTitlePaint)

        // خط فاصل زخرفي
        val decLinePaint = Paint().apply {
            color = redAccent
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawLine(A4_WIDTH / 2f - 80f, 172f, A4_WIDTH / 2f + 80f, 172f, decLinePaint)

        // ج) معلومات التاريخ والاتصال (أعلى اليسار)
        val leftInfoPaint = Paint().apply {
            color = darkText
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
            isAntiAlias = true
        }
        canvas.drawText("التاريخ :  ${data.contractDate}", margin, 75f, leftInfoPaint)
        canvas.drawText("العنوان :  ${officeInfo.address.ifEmpty { "البصرة - حي الحسين" }}", margin, 110f, leftInfoPaint)
        canvas.drawText("الموبايل :  ${officeInfo.phone.ifEmpty { "07700000000" }}", margin, 145f, leftInfoPaint)

        // ==================== 2. شريط البائع الحائز (إن وجد) ====================
        val possessorBarRect = RectF(margin, 190f, A4_WIDTH - margin, 228f)
        val possessorBarBg = Paint().apply {
            color = greenLightBg
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val possessorBarBorder = Paint().apply {
            color = greenPrimary
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(possessorBarRect, 8f, 8f, possessorBarBg)
        canvas.drawRoundRect(possessorBarRect, 8f, 8f, possessorBarBorder)

        val possessorTextPaint = Paint().apply {
            color = darkText
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val posNameText = if (data.possessorName.isNotBlank()) data.possessorName else data.sellerName
        val posPhoneText = if (data.possessorPhone.isNotBlank()) data.possessorPhone else data.sellerPhone
        val posIdText = if (data.possessorIdNumber.isNotBlank()) data.possessorIdNumber else data.sellerIdNumber

        val colW3 = fullWidth / 3f
        drawRtlText(canvas, "البائع الحائز : $posNameText", A4_WIDTH - margin - 15f, 216f, colW3 + 40f, possessorTextPaint, Paint.Align.RIGHT)
        drawRtlText(canvas, "هاتفه : $posPhoneText", A4_WIDTH - margin - colW3 - 20f, 216f, colW3, possessorTextPaint, Paint.Align.RIGHT)
        drawRtlText(canvas, "بطاقته الوطنية : $posIdText", margin + 15f, 216f, colW3, possessorTextPaint, Paint.Align.LEFT)

        // ==================== 3. بطاقتي الطرف الأول والطرف الثاني ====================
        val partyTopY = 242f
        val partyBoxHeight = 210f
        val partyBoxWidth = (fullWidth - 25f) / 2f

        val rightPartyRect = RectF(A4_WIDTH - margin - partyBoxWidth, partyTopY, A4_WIDTH - margin, partyTopY + partyBoxHeight)
        val leftPartyRect = RectF(margin, partyTopY, margin + partyBoxWidth, partyTopY + partyBoxHeight)

        val cardBgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val cardBorderPaint = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }

        canvas.drawRoundRect(rightPartyRect, 10f, 10f, cardBgPaint)
        canvas.drawRoundRect(rightPartyRect, 10f, 10f, cardBorderPaint)

        canvas.drawRoundRect(leftPartyRect, 10f, 10f, cardBgPaint)
        canvas.drawRoundRect(leftPartyRect, 10f, 10f, cardBorderPaint)

        val headerPillPaint = Paint().apply {
            color = greenPrimary
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val headerTitlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightHeaderRect = RectF(rightPartyRect.centerX() - 130f, partyTopY - 14f, rightPartyRect.centerX() + 130f, partyTopY + 24f)
        canvas.drawRoundRect(rightHeaderRect, 12f, 12f, headerPillPaint)
        canvas.drawText("الطرف الأول ( البائع )", rightPartyRect.centerX(), partyTopY + 12f, headerTitlePaint)

        val leftHeaderRect = RectF(leftPartyRect.centerX() - 130f, partyTopY - 14f, leftPartyRect.centerX() + 130f, partyTopY + 24f)
        canvas.drawRoundRect(leftHeaderRect, 12f, 12f, headerPillPaint)
        canvas.drawText("الطرف الثاني ( المشتري )", leftPartyRect.centerX(), partyTopY + 12f, headerTitlePaint)

        // محتوى البائع
        var rY = partyTopY + 60f
        val rRight = rightPartyRect.right - 15f
        val rWidth = rightPartyRect.width() - 30f

        drawFieldWithDots(canvas, "البائع السيد :", data.sellerName, rRight, rY, rWidth)
        rY += 38f
        drawFieldWithDots(canvas, "السكن :", data.sellerAddress, rRight, rY, rWidth)
        rY += 38f
        drawFieldWithDots(canvas, "رقم البطاقة الوطنية :", data.sellerIdNumber, rRight, rY, rWidth)
        rY += 38f
        drawFieldWithDots(canvas, "موبايل :", data.sellerPhone, rRight, rY, rWidth)

        // محتوى المشتري
        var lY = partyTopY + 60f
        val lRight = leftPartyRect.right - 15f
        val lWidth = leftPartyRect.width() - 30f

        drawFieldWithDots(canvas, "المشتري السيد :", data.buyerName, lRight, lY, lWidth)
        lY += 38f
        drawFieldWithDots(canvas, "السكن :", data.buyerAddress, lRight, lY, lWidth)
        lY += 38f
        drawFieldWithDots(canvas, "رقم البطاقة الوطنية :", data.buyerIdNumber, lRight, lY, lWidth)
        lY += 38f
        drawFieldWithDots(canvas, "موبايل :", data.buyerPhone, lRight, lY, lWidth)

        // ==================== 4. مواصفات الدراجة / المركبة (شبكة) ====================
        val secTitleTopY = partyTopY + partyBoxHeight + 18f
        val secTitleRect = RectF(A4_WIDTH / 2f - 270f, secTitleTopY, A4_WIDTH / 2f + 270f, secTitleTopY + 32f)
        val secTitleBg = Paint().apply {
            color = greenLightBg
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val secTitleBorder = Paint().apply {
            color = greenPrimary
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(secTitleRect, 10f, 10f, secTitleBg)
        canvas.drawRoundRect(secTitleRect, 10f, 10f, secTitleBorder)

        val secTitleTextPaint = Paint().apply {
            color = greenPrimary
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("أولاً - بيع الطرف الأول الى الطرف الثاني المركبة المرقمة", secTitleRect.centerX(), secTitleTopY + 22f, secTitleTextPaint)

        val gridTopY = secTitleTopY + 40f
        val gridHeight = 195f
        val gridRect = RectF(margin, gridTopY, A4_WIDTH - margin, gridTopY + gridHeight)

        val gridBorderPaint = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawRoundRect(gridRect, 10f, 10f, gridBorderPaint)

        val rowH = gridHeight / 3f
        val colW = fullWidth / 3f

        canvas.drawLine(gridRect.left, gridTopY + rowH, gridRect.right, gridTopY + rowH, gridBorderPaint)
        canvas.drawLine(gridRect.left, gridTopY + (rowH * 2), gridRect.right, gridTopY + (rowH * 2), gridBorderPaint)

        canvas.drawLine(margin + colW, gridTopY, margin + colW, gridRect.bottom, gridBorderPaint)
        canvas.drawLine(margin + (colW * 2), gridTopY, margin + (colW * 2), gridRect.bottom, gridBorderPaint)

        // الصف الأول
        val y1 = gridTopY + 40f
        drawFieldWithDots(canvas, "رقم الدراجة :", data.registeredNumber, A4_WIDTH - margin - 10f, y1, colW - 20f)
        drawFieldWithDots(canvas, "نوع المركبة :", data.vehicleType, A4_WIDTH - margin - colW - 10f, y1, colW - 20f)
        drawFieldWithDots(canvas, "الماركة :", data.brand, A4_WIDTH - margin - (colW * 2) - 10f, y1, colW - 20f)

        // الصف الثاني
        val y2 = gridTopY + rowH + 40f
        drawFieldWithDots(canvas, "اللون :", data.color, A4_WIDTH - margin - 10f, y2, colW - 20f)
        drawFieldWithDots(canvas, "الحجم :", data.engineCc, A4_WIDTH - margin - colW - 10f, y2, colW - 20f)
        drawFieldWithDots(canvas, "رقم المحرك :", data.engineNumber, A4_WIDTH - margin - (colW * 2) - 10f, y2, colW - 20f)

        // الصف الثالث
        val y3 = gridTopY + (rowH * 2) + 40f
        drawFieldWithDots(canvas, "رقم الشاصي :", data.chassisNumber, A4_WIDTH - margin - 10f, y3, colW - 20f)
        drawFieldWithDots(canvas, "هاتف التواصل :", data.contactPhone, A4_WIDTH - margin - colW - 10f, y3, colW - 20f)
        drawFieldWithDots(canvas, "الملاحظات :", data.notes, A4_WIDTH - margin - (colW * 2) - 10f, y3, colW - 20f)

        // ==================== 5. المبالغ المالية (3 مربعات متجاورة) ====================
        val finTopY = gridRect.bottom + 15f
        val finBoxHeight = 85f
        val finBoxWidth = (fullWidth - 20f) / 3f

        val rightFinRect = RectF(A4_WIDTH - margin - finBoxWidth, finTopY, A4_WIDTH - margin, finTopY + finBoxHeight)
        val middleFinRect = RectF(A4_WIDTH - margin - (finBoxWidth * 2) - 10f, finTopY, A4_WIDTH - margin - finBoxWidth - 10f, finTopY + finBoxHeight)
        val leftFinRect = RectF(margin, finTopY, margin + finBoxWidth, finTopY + finBoxHeight)

        canvas.drawRoundRect(rightFinRect, 8f, 8f, cardBgPaint)
        canvas.drawRoundRect(rightFinRect, 8f, 8f, gridBorderPaint)

        canvas.drawRoundRect(middleFinRect, 8f, 8f, cardBgPaint)
        canvas.drawRoundRect(middleFinRect, 8f, 8f, gridBorderPaint)

        canvas.drawRoundRect(leftFinRect, 8f, 8f, cardBgPaint)
        canvas.drawRoundRect(leftFinRect, 8f, 8f, gridBorderPaint)

        val finLabelPaint = Paint().apply {
            color = darkText
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText("مبلغ قدره", rightFinRect.centerX(), finTopY + 28f, finLabelPaint)
        drawRtlText(
            canvas = canvas,
            text = data.totalPrice,
            x = rightFinRect.centerX(),
            y = finTopY + 68f,
            maxWidth = finBoxWidth - 20f,
            paint = Paint().apply {
                color = darkText
                textSize = 24f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            },
            align = Paint.Align.CENTER
        )

        canvas.drawText("وقد استلم البائع مبلغ قدره", middleFinRect.centerX(), finTopY + 28f, finLabelPaint)
        drawRtlText(
            canvas = canvas,
            text = data.paidAmount,
            x = middleFinRect.centerX(),
            y = finTopY + 68f,
            maxWidth = finBoxWidth - 20f,
            paint = Paint().apply {
                color = greenPrimary
                textSize = 24f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            },
            align = Paint.Align.CENTER
        )

        canvas.drawText("والباقي قدره", leftFinRect.centerX(), finTopY + 28f, finLabelPaint)
        drawRtlText(
            canvas = canvas,
            text = data.remainingAmount,
            x = leftFinRect.centerX(),
            y = finTopY + 68f,
            maxWidth = finBoxWidth - 20f,
            paint = Paint().apply {
                color = redAccent
                textSize = 24f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            },
            align = Paint.Align.CENTER
        )

        // ==================== 6. البنود والشروط القانونية ====================
        var clauseY = finTopY + finBoxHeight + 15f
        val vehicleNoun = getVehicleDefiniteNoun(data.vehicleType)
        val clauses = listOf(
            Pair("ثانياً", "المباع لا يرجع ولا يبدل بعد توقيع هذا العقد والاستلام."),
            Pair("ثالثاً", "اشتريت $vehicleNoun بعد المعاينة التامة من مالكها الشرعي وتعهد بسداد كافة مستحقاتها."),
            Pair("رابعاً", "على الطرفين تسجيل $vehicleNoun حسب قوانين المرور والمعرض غير مسؤول خلاف ذلك."),
            Pair("خامساً", "الطرف الأول مسؤول عن دفع كافة الغرامات المرورية والضرائب المترتبة على $vehicleNoun لغاية تاريخ العقد."),
            Pair("سادساً", "يعتبر هذا الوصل ملغياً بعد تنظيم العقد المروري، وتبلغ الطرفان بمعرفة دار كل منهما.")
        )

        val clauseBoxHeight = 52f
        val clauseBoxBg = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val clauseBoxBorder = Paint().apply {
            color = borderGray
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        val tagBgPaint = Paint().apply {
            color = Color.parseColor("#F1F5F9")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val tagTextPaint = Paint().apply {
            color = darkText
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val clauseTextPaint = Paint().apply {
            color = darkText
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        for (clause in clauses) {
            val cRect = RectF(margin, clauseY, A4_WIDTH - margin, clauseY + clauseBoxHeight)
            canvas.drawRoundRect(cRect, 8f, 8f, clauseBoxBg)
            canvas.drawRoundRect(cRect, 8f, 8f, clauseBoxBorder)

            val tagRect = RectF(A4_WIDTH - margin - 80f, clauseY + 6f, A4_WIDTH - margin - 6f, clauseY + clauseBoxHeight - 6f)
            canvas.drawRoundRect(tagRect, 6f, 6f, tagBgPaint)
            canvas.drawText(clause.first, tagRect.centerX(), clauseY + 32f, tagTextPaint)

            drawRtlText(
                canvas = canvas,
                text = clause.second,
                x = A4_WIDTH - margin - 95f,
                y = clauseY + 32f,
                maxWidth = fullWidth - 110f,
                paint = clauseTextPaint,
                align = Paint.Align.RIGHT
            )

            clauseY += clauseBoxHeight + 8f
        }

        // تاريخ التحرير
        clauseY += 10f
        val dateLineText = "حرر بتاريخ :  ${data.contractDate}  كتابةً"
        val greenDatePaint = Paint().apply {
            color = greenPrimary
            textSize = 19f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(dateLineText, A4_WIDTH - margin, clauseY, greenDatePaint)

        // ==================== 7. مربع بصمات الأختام ====================
        val stampY = clauseY + 20f
        val stampHeight = 110f
        val stampWidth = (fullWidth - 30f) / 3f

        val stampBoxPaint = Paint().apply {
            color = Color.parseColor("#FAFAFA")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val stampBorderPaint = Paint().apply {
            color = borderGray
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
            pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
            isAntiAlias = true
        }
        val stampTextPaint = Paint().apply {
            color = darkText
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightStamp = RectF(A4_WIDTH - margin - stampWidth, stampY, A4_WIDTH - margin, stampY + stampHeight)
        val middleStamp = RectF(A4_WIDTH - margin - (stampWidth * 2) - 15f, stampY, A4_WIDTH - margin - stampWidth - 15f, stampY + stampHeight)
        val leftStamp = RectF(margin, stampY, margin + stampWidth, stampY + stampHeight)

        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة ابهام البائع", rightStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("ختم المعرض والتوقيع", middleStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة ابهام المشتري", leftStamp.centerX(), stampY + 65f, stampTextPaint)

        // ==================== 8. صف التواقيع أسفل العقد ====================
        val witnessTitle = if (data.witnessName.isNotBlank()) "الشاهد: ${data.witnessName}" else "الشهود"
        drawSignatures(
            canvas = canvas,
            titles = listOf("الطرف الأول (البائع)", witnessTitle, "منظم العقد", "الطرف الثاني (المشتري)"),
            bottomY = A4_HEIGHT - 185f
        )
    }

    companion object {
        fun getVehicleDefiniteNoun(vehicleType: String): String {
            val clean = vehicleType.trim()
            if (clean.isEmpty()) return "المركبة"
            return when {
                clean == "تكتك" -> "التكتك"
                clean == "تك تك" -> "التك تك"
                clean == "ستوتة" || clean == "ستوته" -> "الستوتة"
                clean == "دراجة نارية" || clean == "دراجة" -> "الدراجة"
                clean == "سيارة" -> "السيارة"
                clean.startsWith("ال") -> clean
                else -> "ال$clean"
            }
        }
    }
}

