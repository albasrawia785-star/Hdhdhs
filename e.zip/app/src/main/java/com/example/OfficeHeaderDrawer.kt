package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint

/**
 * دالة عامة موحدة لإسقاط ورسم رأس العقد الاحترافي (Header Area) في كافة استمارات وقوالب العقود الـ A4
 * تفوض العمليات إلى HeaderRenderer طبقاً لمعايير Clean Architecture
 */
object OfficeHeaderDrawer {

    /**
     * رسم رأس العقد الاحترافي الموحد (Header Area)
     */
    fun drawContractHeader(
        canvas: Canvas,
        officeInfo: OfficeInfo,
        contractType: ContractType,
        pageWidth: Float = 1240f,
        pageHeight: Float = 1754f,
        startY: Float = 45f,
        context: Context? = null
    ): Float {
        val template = ContractTemplateManager.getTemplate(contractType)
        return HeaderRenderer.renderHeader(
            canvas = canvas,
            officeInfo = officeInfo,
            contractTitle = template.title,
            contractNo = "0000",
            contractDate = "____/____/2026",
            context = context,
            pageWidth = pageWidth,
            pageHeight = pageHeight,
            startY = startY
        )
    }

    /**
     * رسم بيانات المكتب الترويسية السريعة
     */
    fun drawOfficeInfo(
        canvas: Canvas,
        officeInfo: OfficeInfo,
        pageWidth: Float,
        pageHeight: Float,
        customPaint: Paint? = null
    ) {
        HeaderRenderer.renderHeader(
            canvas = canvas,
            officeInfo = officeInfo,
            contractTitle = "عقد رسميي",
            contractNo = "",
            contractDate = "",
            pageWidth = pageWidth,
            pageHeight = pageHeight
        )
    }
}

/**
 * دالة عامة موحدة علوية باسم drawContractHeader
 */
fun drawContractHeader(
    canvas: Canvas,
    officeInfo: OfficeInfo,
    contractType: ContractType,
    pageWidth: Float = 1240f,
    pageHeight: Float = 1754f,
    startY: Float = 45f,
    context: Context? = null
): Float {
    val template = ContractTemplateManager.getTemplate(contractType)
    return HeaderRenderer.renderHeader(
        canvas = canvas,
        officeInfo = officeInfo,
        contractTitle = template.title,
        contractNo = "0000",
        contractDate = "____/____/2026",
        context = context,
        pageWidth = pageWidth,
        pageHeight = pageHeight,
        startY = startY
    )
}

/**
 * دالة عامة علوية لتسهيل الاستدعاء المباشر لـ drawOfficeInfo
 */
fun drawOfficeInfo(
    canvas: Canvas,
    officeInfo: OfficeInfo,
    pageWidth: Float,
    pageHeight: Float
) {
    OfficeHeaderDrawer.drawOfficeInfo(canvas, officeInfo, pageWidth, pageHeight)
}
