package com.example

/**
 * نموذج بيانات المكتب/المعرض للترويسة الرسمية
 * يحتوي حصرياً على اسم المكتب ورقم الهاتف والعنوان
 */
data class OfficeInfo(
    val officeName: String = "",
    val phone: String = "",
    val address: String = ""
) {
    /**
     * تحقق مما إذا كانت بيانات المكتب فارغة بالكامل
     */
    fun isBlank(): Boolean = officeName.isBlank() && phone.isBlank() && address.isBlank()
}
