package com.example

import android.content.Context
import android.graphics.*

/**
 * RealEstateContractRenderer: محرك رسم عقد بيع وشراء الدور والأراضي السكنية والزراعية
 * مطابق 100% للتصميم العراقي الرسمي المعتمد في الصورة المرفقة.
 */
class RealEstateContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? RealEstateContract ?: RealEstateContract()

        val margin = 45f
        val fullWidth = A4_WIDTH - (margin * 2)

        val greenPrimary = Color.parseColor("#047857")
        val redAccent = Color.parseColor("#D32F2F")
        val darkText = Color.parseColor("#1E293B")

        // ==================== 1. الترويسة الهيدر العلوي ====================
        val headerOuterRect = RectF(margin, 35f, A4_WIDTH - margin, 170f)
        val headerBorderPaint = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawRoundRect(headerOuterRect, 10f, 10f, headerBorderPaint)

        // أ) رسم عنوان العقد في المنتصف
        val mainTitlePaint = Paint().apply {
            color = greenPrimary
            textSize = 46f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("عقد بيع وشراء", A4_WIDTH / 2f, 88f, mainTitlePaint)

        val subtitlePaint = Paint().apply {
            color = redAccent
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("الدور والاراضي السكنية والزراعية", A4_WIDTH / 2f, 130f, subtitlePaint)

        // ب) مربع رقم العقد (أعلى اليسار)
        val noBoxRect = RectF(margin + 15f, 115f, margin + 175f, 155f)
        val noBoxBorder = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        val noBoxBg = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(noBoxRect, 8f, 8f, noBoxBg)
        canvas.drawRoundRect(noBoxRect, 8f, 8f, noBoxBorder)

        val noValPaint = Paint().apply {
            color = redAccent
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("NO : ${data.contractNo.ifEmpty { "0025" }}", noBoxRect.centerX(), 142f, noValPaint)

        // ==================== 2. بطاقتي الطرف الأول والطرف الثاني ====================
        val partyTopY = 185f
        val partyBoxHeight = 185f
        val partyBoxWidth = (fullWidth - 20f) / 2f

        val rightPartyRect = RectF(A4_WIDTH - margin - partyBoxWidth, partyTopY, A4_WIDTH - margin, partyTopY + partyBoxHeight)
        val leftPartyRect = RectF(margin, partyTopY, margin + partyBoxWidth, partyTopY + partyBoxHeight)

        val cardBgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val cardBorderPaint = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }

        canvas.drawRoundRect(rightPartyRect, 10f, 10f, cardBgPaint)
        canvas.drawRoundRect(rightPartyRect, 10f, 10f, cardBorderPaint)

        canvas.drawRoundRect(leftPartyRect, 10f, 10f, cardBgPaint)
        canvas.drawRoundRect(leftPartyRect, 10f, 10f, cardBorderPaint)

        val headerPillPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val pillBorderPaint = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        val headerTitlePaint = Paint().apply {
            color = darkText
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightHeaderRect = RectF(rightPartyRect.centerX() - 120f, partyTopY - 14f, rightPartyRect.centerX() + 120f, partyTopY + 18f)
        canvas.drawRoundRect(rightHeaderRect, 10f, 10f, headerPillPaint)
        canvas.drawRoundRect(rightHeaderRect, 10f, 10f, pillBorderPaint)
        canvas.drawText("الطرف الاول ( البائع )", rightPartyRect.centerX(), partyTopY + 8f, headerTitlePaint)

        val leftHeaderRect = RectF(leftPartyRect.centerX() - 120f, partyTopY - 14f, leftPartyRect.centerX() + 120f, partyTopY + 18f)
        canvas.drawRoundRect(leftHeaderRect, 10f, 10f, headerPillPaint)
        canvas.drawRoundRect(leftHeaderRect, 10f, 10f, pillBorderPaint)
        canvas.drawText("الطرف الثاني ( المشتري )", leftPartyRect.centerX(), partyTopY + 8f, headerTitlePaint)

        // محتوى البائع
        var rY = partyTopY + 48f
        val rRight = rightPartyRect.right - 15f
        val rWidth = rightPartyRect.width() - 30f

        val redLabelPaint = Paint().apply {
            color = redAccent
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        drawFieldWithColoredLabel(canvas, "البائع :", data.sellerName, rRight, rY, rWidth, redLabelPaint)
        rY += 36f
        drawFieldWithColoredLabel(canvas, "العنوان :", data.sellerAddress, rRight, rY, rWidth, redLabelPaint)
        rY += 36f
        drawFieldWithColoredLabel(canvas, "رقم الهوية :", data.sellerIdNumber, rRight, rY, rWidth, redLabelPaint)
        rY += 36f
        drawFieldWithColoredLabel(canvas, "الهاتف :", data.sellerPhone, rRight, rY, rWidth, redLabelPaint)

        // محتوى المشتري
        var lY = partyTopY + 48f
        val lRight = leftPartyRect.right - 15f
        val lWidth = leftPartyRect.width() - 30f

        val greenLabelPaint = Paint().apply {
            color = greenPrimary
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        drawFieldWithColoredLabel(canvas, "المشتري :", data.buyerName, lRight, lY, lWidth, greenLabelPaint)
        lY += 36f
        drawFieldWithColoredLabel(canvas, "العنوان :", data.buyerAddress, lRight, lY, lWidth, greenLabelPaint)
        lY += 36f
        drawFieldWithColoredLabel(canvas, "رقم الهوية :", data.buyerIdNumber, lRight, lY, lWidth, greenLabelPaint)
        lY += 36f
        drawFieldWithColoredLabel(canvas, "الهاتف :", data.buyerPhone, lRight, lY, lWidth, greenLabelPaint)

        // ==================== 3. المقدمة الإقرارية ====================
        val introY = partyTopY + partyBoxHeight + 25f
        val introTextPaint = Paint().apply {
            color = greenPrimary
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText("لقد تم الاتفاق بين الطرفين على انعقاد هذا العقد وبالشروط الاتية :", A4_WIDTH - margin, introY, introTextPaint)

        // ==================== 4. بنود العقد ونص العقد الرسمي ====================
        var currY = introY + 38f

        // اولا - أ
        drawFirstClauseHeader(canvas, currY, margin)
        currY += 36f

        // نوع الملك / المساحة
        val halfW = (fullWidth - 40f) / 2f
        drawFieldWithColoredLabel(canvas, "نوع الملك :", data.propertyType, A4_WIDTH - margin, currY, halfW, redLabelPaint)
        drawFieldWithColoredLabel(canvas, "المساحة :", data.propertyArea, A4_WIDTH - margin - halfW - 40f, currY, halfW, redLabelPaint)
        currY += 38f

        // الرقم والتسلسل / المحلة
        drawFieldWithColoredLabel(canvas, "الرقم والتسلسل :", data.plotSequenceNo, A4_WIDTH - margin, currY, halfW, redLabelPaint)
        drawFieldWithColoredLabel(canvas, "المحلة :", data.neighborhood, A4_WIDTH - margin - halfW - 40f, currY, halfW, redLabelPaint)
        currY += 42f

        // ب . بدل البيع المتفق عليه
        drawFieldWithColoredLabel(canvas, "ب . بدل البيع المتفق عليه :", if (data.totalPrice.isNotBlank()) "${data.totalPrice} دينار" else "", A4_WIDTH - margin, currY, fullWidth, redLabelPaint)
        currY += 38f

        // جـ . العربون الذي تم قبضه
        drawFieldWithColoredLabel(canvas, "جـ . العربون الذي تم قبضه :", if (data.depositPrice.isNotBlank()) "${data.depositPrice} دينار" else "", A4_WIDTH - margin, currY, fullWidth, redLabelPaint)
        currY += 38f

        // الباقي
        drawFieldWithColoredLabel(canvas, "الباقي :", if (data.remainingPrice.isNotBlank()) "${data.remainingPrice} دينار" else "", A4_WIDTH - margin, currY, fullWidth, redLabelPaint)
        currY += 42f

        // د . امتناع البائع
        val penaltySellerStr = if (data.penaltySellerAmount.isNotBlank()) "${data.penaltySellerAmount} دينار" else ""
        drawLongClauseWithField(
            canvas = canvas,
            prefixText = "د . اذا امتنعت الطرف الاول ( البائع ) عن اجراء التقرير او نكل عن البيع باي صورة كانت فانه ملزم باعادة العربون ويتعهد بدفع تضمينات الى الطرف الثاني ( المشتري ) قدرها :",
            valueText = penaltySellerStr,
            suffixText = "دينار",
            y = currY,
            margin = margin,
            fullWidth = fullWidth
        )
        currY += 65f

        // ثانيا - امتناع المشتري
        val penaltyBuyerStr = if (data.penaltyBuyerAmount.isNotBlank()) "${data.penaltyBuyerAmount} دينار" else ""
        drawLongClauseWithField(
            canvas = canvas,
            prefixText = "ثانيا - يعترف الطرف الثاني ( المشتري ) بانه قد قبل الشراءوفي حالة عدم التقرير او النكول عن الشراء وتأدية قصور البدل فانه يتعهد بتأدية تضمينات الى الطرف الاول ( البائع ) قدرها :",
            valueText = penaltyBuyerStr,
            suffixText = "دينار",
            y = currY,
            margin = margin,
            fullWidth = fullWidth
        )
        currY += 65f

        // ثالثا
        drawNormalClause(canvas, "ثالثا - يحق للطرف الثاني ( المشتري ) تقرير الملك لمن يشاء .", currY, margin)
        currY += 38f

        // رابعا
        drawNormalClause(canvas, "رابعا : كل مكاتبة غير مختومة بختم المكتب تعتبر باطلة", currY, margin)
        currY += 38f

        // خامسا
        drawNormalClause(canvas, "خامسا - لا تسترجع الدلالية عند حصول اي خلاف بين الطرفين بعد ابرام العقد .", currY, margin)
        currY += 38f

        // ملاحظات الدلالية
        drawNormalClause(canvas, "ملاحظات - نسبة الدلالية ٢% والمكتب غير مسؤول بعد التقرير عن الفقرات الاضافية .", currY, margin)
        currY += 45f

        // فبناء على حصول التراضي
        val city = officeInfo.address.ifEmpty { "البصرة" }
        val finalDateText = "فبناء على حصول التراضي والايجاب والقبول قرر هذا العقد في  $city  بتاريخ  ${data.contractDate}"
        val finalDatePaint = Paint().apply {
            color = darkText
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(finalDateText, A4_WIDTH - margin, currY, finalDatePaint)
        currY += 45f

        // ملاحظات اضافية
        val notesTitlePaint = Paint().apply {
            color = redAccent
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText("ملاحظات اضافية", A4_WIDTH - margin, currY, notesTitlePaint)
        currY += 25f

        // رسم أسطر الملاحظات الإضافية
        val notesText = data.additionalNotes
        val dotPaintLine = Paint().apply {
            color = Color.GRAY
            textSize = 18f
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        if (notesText.isNotBlank()) {
            drawRtlText(
                canvas = canvas,
                text = notesText,
                x = A4_WIDTH - margin,
                y = currY,
                maxWidth = fullWidth,
                paint = valuePaint,
                align = Paint.Align.RIGHT
            )
        } else {
            val dotsLine = ".........................................................................................................................................................................."
            canvas.drawText(dotsLine, A4_WIDTH - margin, currY, dotPaintLine)
            canvas.drawText(dotsLine, A4_WIDTH - margin, currY + 30f, dotPaintLine)
        }

        // ==================== 5. التواقيع في الأسفل ====================
        val signatureY = A4_HEIGHT - 120f
        val colWidth = fullWidth / 4f

        val redSigPaint = Paint().apply {
            color = redAccent
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val darkSigPaint = Paint().apply {
            color = darkText
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val greenSigPaint = Paint().apply {
            color = greenPrimary
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        // 1. البائع (اليمين)
        canvas.drawText("الطرف الاول/البائع", A4_WIDTH - margin - (colWidth * 0.5f), signatureY, redSigPaint)

        // 2. الشاهد الأول
        val w1Text = if (data.witness1Name.isNotBlank()) "الشاهد : ${data.witness1Name}" else "الشاهد الاول"
        canvas.drawText(w1Text, A4_WIDTH - margin - (colWidth * 1.5f), signatureY, darkSigPaint)

        // 3. الشاهد الثاني
        val w2Text = if (data.witness2Name.isNotBlank()) "الشاهد : ${data.witness2Name}" else "الشاهد الثاني"
        canvas.drawText(w2Text, A4_WIDTH - margin - (colWidth * 2.5f), signatureY, darkSigPaint)

        // 4. المشتري (اليسار)
        canvas.drawText("الطرف الثاني/المشتري", A4_WIDTH - margin - (colWidth * 3.5f), signatureY, greenSigPaint)
    }

    private fun drawFieldWithColoredLabel(
        canvas: Canvas,
        label: String,
        value: String,
        x: Float,
        y: Float,
        totalWidth: Float,
        lblPaint: Paint
    ) {
        lblPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(label, x, y, lblPaint)

        val labelW = lblPaint.measureText(label) + 12f
        val valueX = x - labelW
        val availableW = totalWidth - labelW

        if (value.isBlank()) {
            val dotsCount = (availableW / 7f).toInt().coerceAtLeast(5)
            val dots = ".".repeat(dotsCount)
            dotPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(dots, valueX, y, dotPaint)
        } else {
            drawRtlText(
                canvas = canvas,
                text = value,
                x = valueX,
                y = y,
                maxWidth = availableW,
                paint = valuePaint,
                align = Paint.Align.RIGHT
            )
        }
    }

    private fun drawFirstClauseHeader(canvas: Canvas, y: Float, margin: Float) {
        val redP = Paint().apply {
            color = Color.parseColor("#D32F2F")
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val darkP = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val greenP = Paint().apply {
            color = Color.parseColor("#047857")
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        var curX = A4_WIDTH - margin

        canvas.drawText("اولا - أ - ", curX, y, redP)
        curX -= redP.measureText("اولا - أ - ")

        canvas.drawText("يعترف الطرف الاول ", curX, y, darkP)
        curX -= darkP.measureText("يعترف الطرف الاول ")

        canvas.drawText("( البائع ) ", curX, y, redP)
        curX -= redP.measureText("( البائع ) ")

        canvas.drawText("بانه قد باع للطرف الثاني ", curX, y, darkP)
        curX -= darkP.measureText("بانه قد باع للطرف الثاني ")

        canvas.drawText("( المشتري ) ", curX, y, greenP)
        curX -= greenP.measureText("( المشتري ) ")

        canvas.drawText("الملك المفصل فيما يلي .", curX, y, darkP)
    }

    private fun drawLongClauseWithField(
        canvas: Canvas,
        prefixText: String,
        valueText: String,
        suffixText: String,
        y: Float,
        margin: Float,
        fullWidth: Float
    ) {
        val textPaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        val lines = splitTextToLines(prefixText, textPaint, fullWidth)
        var lineY = y
        for (line in lines) {
            canvas.drawText(line, A4_WIDTH - margin, lineY, textPaint)
            lineY += 26f
        }

        val lastLineW = textPaint.measureText(lines.lastOrNull() ?: "")
        val valX = A4_WIDTH - margin - lastLineW - 10f

        if (valueText.isBlank()) {
            val dots = "........................................"
            dotPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(dots, valX, lineY - 26f, dotPaint)
        } else {
            drawRtlText(
                canvas = canvas,
                text = valueText,
                x = valX,
                y = lineY - 26f,
                maxWidth = 200f,
                paint = valuePaint,
                align = Paint.Align.RIGHT
            )
        }
    }

    private fun splitTextToLines(text: String, paint: Paint, maxWidth: Float): List<String> {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = ""

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(testLine) <= maxWidth) {
                currentLine = testLine
            } else {
                if (currentLine.isNotEmpty()) lines.add(currentLine)
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) lines.add(currentLine)
        return lines
    }

    private fun drawNormalClause(canvas: Canvas, text: String, y: Float, margin: Float) {
        val darkP = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(text, A4_WIDTH - margin, y, darkP)
    }
}
