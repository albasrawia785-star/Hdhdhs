package com.example

import android.content.Context
import android.graphics.*

/**
 * RentalContractRenderer: محرك رسم عقد إيجار العقارات والدور والمحلات
 * مطابق 100% للتصميم العراقي الرسمي المعتمد في المعارض والمكاتب الرسمية.
 */
class RentalContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? RentalContract ?: RentalContract()

        val margin = 40f
        val fullWidth = A4_WIDTH - (margin * 2)

        val greenPrimary = Color.parseColor("#047857")
        val greenLightBg = Color.parseColor("#F0FDF4")
        val redAccent = Color.parseColor("#D32F2F")
        val darkText = Color.parseColor("#1E293B")
        val borderGray = Color.parseColor("#CBD5E1")

        // ==================== 1. الترويسة الهيدر العلوي ====================
        // أ) مربع رقم العقد (أعلى اليمين)
        val noBoxRect = RectF(A4_WIDTH - margin - 220f, 45f, A4_WIDTH - margin, 125f)
        val noBoxBorder = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        val noBoxBg = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(noBoxRect, 10f, 10f, noBoxBg)
        canvas.drawRoundRect(noBoxRect, 10f, 10f, noBoxBorder)

        val noHeaderPaint = Paint().apply {
            color = darkText
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val noValPaint = Paint().apply {
            color = redAccent
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("رقم العقد", noBoxRect.centerX(), 72f, noHeaderPaint)
        canvas.drawText("№  ${data.contractNo.ifEmpty { "001024" }}", noBoxRect.centerX(), 108f, noValPaint)


        // ب) ترويسة اسم المكتب والشعار (المنتصف)
        val officeNameText = officeInfo.officeName.ifEmpty { "مكتب السلام للعقارات والإيجارات" }
        val galleryNamePaint = Paint().apply {
            color = greenPrimary
            textSize = 36f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(officeNameText, A4_WIDTH / 2f, 80f, galleryNamePaint)

        // شريط أحمر خلف عبارة الوصف
        val pillRect = RectF(A4_WIDTH / 2f - 170f, 95f, A4_WIDTH / 2f + 170f, 125f)
        val pillBg = Paint().apply {
            color = redAccent
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(pillRect, 15f, 15f, pillBg)

        val pillTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("لتأجير العقارات والدور والمحلات التجارية", A4_WIDTH / 2f, 117f, pillTextPaint)

        // عنوان العقد
        val mainTitlePaint = Paint().apply {
            color = darkText
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("عقــد إيجـــار عقـــار", A4_WIDTH / 2f, 158f, mainTitlePaint)

        // خط فاصل زخرفي
        val decLinePaint = Paint().apply {
            color = redAccent
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawLine(A4_WIDTH / 2f - 80f, 172f, A4_WIDTH / 2f + 80f, 172f, decLinePaint)

        // ج) معلومات التاريخ والاتصال (أعلى اليسار)
        val leftInfoPaint = Paint().apply {
            color = darkText
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
            isAntiAlias = true
        }
        canvas.drawText("التاريخ :  ${data.signDate}", margin, 75f, leftInfoPaint)
        canvas.drawText("العنوان :  ${officeInfo.address.ifEmpty { "البصرة - حي الحسين" }}", margin, 110f, leftInfoPaint)
        canvas.drawText("الموبايل :  ${officeInfo.phone.ifEmpty { "07700000000" }}", margin, 145f, leftInfoPaint)

        // ==================== 2. شريط المقدمة الإقرارية ====================
        val ownerBarRect = RectF(margin, 190f, A4_WIDTH - margin, 228f)
        val ownerBarBg = Paint().apply {
            color = greenLightBg
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val ownerBarBorder = Paint().apply {
            color = greenPrimary
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(ownerBarRect, 8f, 8f, ownerBarBg)
        canvas.drawRoundRect(ownerBarRect, 8f, 8f, ownerBarBorder)

        val introTextPaint = Paint().apply {
            color = greenPrimary
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val seqText = if (data.sequenceNumber.isNotBlank()) "ت : ${data.sequenceNumber}" else ""
        val doorText = if (data.doorsNumber.isNotBlank()) "أبواب رقم : ${data.doorsNumber}" else ""
        val barDesc = listOf(seqText, doorText).filter { it.isNotBlank() }.joinToString(" | ")
        val barFullText = if (barDesc.isNotBlank()) "عقد إيجار رسمـي ($barDesc) تم الاتفاق بالتراضي التام بين المؤجر والمستأجر" else "تم الاتفاق بين الطرفين المؤجر والمستأجر على إيجار العقار المبين أدناه بالشروط التالية :"
        canvas.drawText(barFullText, ownerBarRect.centerX(), 216f, introTextPaint)

        // ==================== 3. بطاقتي الطرف الأول والطرف الثاني ====================
        val partyTopY = 242f
        val partyBoxHeight = 210f
        val partyBoxWidth = (fullWidth - 25f) / 2f

        val rightPartyRect = RectF(A4_WIDTH - margin - partyBoxWidth, partyTopY, A4_WIDTH - margin, partyTopY + partyBoxHeight)
        val leftPartyRect = RectF(margin, partyTopY, margin + partyBoxWidth, partyTopY + partyBoxHeight)

        val cardBgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val cardBorderPaint = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }

        canvas.drawRoundRect(rightPartyRect, 10f, 10f, cardBgPaint)
        canvas.drawRoundRect(rightPartyRect, 10f, 10f, cardBorderPaint)

        canvas.drawRoundRect(leftPartyRect, 10f, 10f, cardBgPaint)
        canvas.drawRoundRect(leftPartyRect, 10f, 10f, cardBorderPaint)

        val headerPillPaint = Paint().apply {
            color = greenPrimary
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val headerTitlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightHeaderRect = RectF(rightPartyRect.centerX() - 130f, partyTopY - 14f, rightPartyRect.centerX() + 130f, partyTopY + 24f)
        canvas.drawRoundRect(rightHeaderRect, 12f, 12f, headerPillPaint)
        canvas.drawText("الطرف الأول ( المؤجر )", rightPartyRect.centerX(), partyTopY + 12f, headerTitlePaint)

        val leftHeaderRect = RectF(leftPartyRect.centerX() - 130f, partyTopY - 14f, leftPartyRect.centerX() + 130f, partyTopY + 24f)
        canvas.drawRoundRect(leftHeaderRect, 12f, 12f, headerPillPaint)
        canvas.drawText("الطرف الثاني ( المستأجر )", leftPartyRect.centerX(), partyTopY + 12f, headerTitlePaint)

        // محتوى المؤجر
        var rY = partyTopY + 60f
        val rRight = rightPartyRect.right - 15f
        val rWidth = rightPartyRect.width() - 30f

        drawFieldWithDots(canvas, "المؤجر السيد :", data.lessorName, rRight, rY, rWidth)
        rY += 38f
        drawFieldWithDots(canvas, "العنوان والواقع :", data.propertyLocation, rRight, rY, rWidth)
        rY += 38f
        drawFieldWithDots(canvas, "المحلة :", data.neighborhood, rRight, rY, rWidth)
        rY += 38f
        drawFieldWithDots(canvas, "زقاق / دار :", data.alleyNumber, rRight, rY, rWidth)

        // محتوى المستأجر
        var lY = partyTopY + 60f
        val lRight = leftPartyRect.right - 15f
        val lWidth = leftPartyRect.width() - 30f

        drawFieldWithDots(canvas, "المستأجر السيد :", data.lesseeName, lRight, lY, lWidth)
        lY += 38f
        drawFieldWithDots(canvas, "حق السكن والصفة :", data.dwellingRightDetails, lRight, lY, lWidth)
        lY += 38f
        drawFieldWithDots(canvas, "مدة الإيجار :", data.leaseDuration, lRight, lY, lWidth)
        lY += 38f
        drawFieldWithDots(canvas, "العائد للمستأجر :", data.returnToLesseeText, lRight, lY, lWidth)

        // ==================== 4. مواصفات العين المؤجرة وملازمتها (شبكة) ====================
        val secTitleTopY = partyTopY + partyBoxHeight + 18f
        val secTitleRect = RectF(A4_WIDTH / 2f - 270f, secTitleTopY, A4_WIDTH / 2f + 270f, secTitleTopY + 32f)
        val secTitleBg = Paint().apply {
            color = greenLightBg
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val secTitleBorder = Paint().apply {
            color = greenPrimary
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        canvas.drawRoundRect(secTitleRect, 10f, 10f, secTitleBg)
        canvas.drawRoundRect(secTitleRect, 10f, 10f, secTitleBorder)

        val secTitleTextPaint = Paint().apply {
            color = greenPrimary
            textSize = 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("أولاً - إيجار منفعة العين المؤجرة بالخواص والمواصفات أدناه", secTitleRect.centerX(), secTitleTopY + 22f, secTitleTextPaint)

        val gridTopY = secTitleTopY + 40f
        val gridHeight = 130f
        val gridRect = RectF(margin, gridTopY, A4_WIDTH - margin, gridTopY + gridHeight)

        val gridBorderPaint = Paint().apply {
            color = darkText
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        canvas.drawRoundRect(gridRect, 10f, 10f, gridBorderPaint)

        val rowH = gridHeight / 2f
        val colW = fullWidth / 2f

        canvas.drawLine(gridRect.left, gridTopY + rowH, gridRect.right, gridTopY + rowH, gridBorderPaint)
        canvas.drawLine(margin + colW, gridTopY, margin + colW, gridRect.bottom, gridBorderPaint)

        // الصف الأول
        val y1 = gridTopY + 42f
        drawFieldWithDots(canvas, "العين المؤجرة :", data.rentedPropertyDescription, A4_WIDTH - margin - 10f, y1, colW - 20f)
        drawFieldWithDots(canvas, "الموقع والمحلة :", "${data.propertyLocation} - ${data.neighborhood}", A4_WIDTH - margin - colW - 10f, y1, colW - 20f)

        // الصف الثاني
        val y2 = gridTopY + rowH + 42f
        drawFieldWithDots(canvas, "مدة الإيجار :", data.leaseDuration, A4_WIDTH - margin - 10f, y2, colW - 20f)
        drawFieldWithDots(canvas, "الفترة الزمنية :", "من ${data.startDate} إلى ${data.endDate}", A4_WIDTH - margin - colW - 10f, y2, colW - 20f)

        // ==================== 5. المبالغ المالية (3 مربعات متجاورة) ====================
        val finTopY = gridRect.bottom + 15f
        val finBoxHeight = 85f
        val finBoxWidth = (fullWidth - 20f) / 3f

        val rightFinRect = RectF(A4_WIDTH - margin - finBoxWidth, finTopY, A4_WIDTH - margin, finTopY + finBoxHeight)
        val middleFinRect = RectF(A4_WIDTH - margin - (finBoxWidth * 2) - 10f, finTopY, A4_WIDTH - margin - finBoxWidth - 10f, finTopY + finBoxHeight)
        val leftFinRect = RectF(margin, finTopY, margin + finBoxWidth, finTopY + finBoxHeight)

        canvas.drawRoundRect(rightFinRect, 8f, 8f, cardBgPaint)
        canvas.drawRoundRect(rightFinRect, 8f, 8f, gridBorderPaint)

        canvas.drawRoundRect(middleFinRect, 8f, 8f, cardBgPaint)
        canvas.drawRoundRect(middleFinRect, 8f, 8f, gridBorderPaint)

        canvas.drawRoundRect(leftFinRect, 8f, 8f, cardBgPaint)
        canvas.drawRoundRect(leftFinRect, 8f, 8f, gridBorderPaint)

        val finLabelPaint = Paint().apply {
            color = darkText
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawText("بدل الإيجار الشهري", rightFinRect.centerX(), finTopY + 28f, finLabelPaint)
        val displayRent = if (data.rentAmountNumber.isNotBlank()) "${data.rentAmountNumber} دينار" else data.rentAmountWords
        drawRtlText(
            canvas = canvas,
            text = displayRent,
            x = rightFinRect.centerX(),
            y = finTopY + 68f,
            maxWidth = finBoxWidth - 20f,
            paint = Paint().apply {
                color = darkText
                textSize = 21f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            },
            align = Paint.Align.CENTER
        )

        canvas.drawText("بدل غرامة التأخير اليومي", middleFinRect.centerX(), finTopY + 28f, finLabelPaint)
        drawRtlText(
            canvas = canvas,
            text = if (data.dailyDelayFee.isNotBlank()) "${data.dailyDelayFee} دينار" else "حسب القانون",
            x = middleFinRect.centerX(),
            y = finTopY + 68f,
            maxWidth = finBoxWidth - 20f,
            paint = Paint().apply {
                color = greenPrimary
                textSize = 21f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            },
            align = Paint.Align.CENTER
        )

        canvas.drawText("ضريبة الأملاك على", leftFinRect.centerX(), finTopY + 28f, finLabelPaint)
        drawRtlText(
            canvas = canvas,
            text = data.propertyTaxOwner.ifEmpty { "المؤجر" },
            x = leftFinRect.centerX(),
            y = finTopY + 68f,
            maxWidth = finBoxWidth - 20f,
            paint = Paint().apply {
                color = redAccent
                textSize = 21f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            },
            align = Paint.Align.CENTER
        )

        // ==================== 6. البنود والشروط القانونية ====================
        var clauseY = finTopY + finBoxHeight + 15f
        val delayFeeText = if (data.dailyDelayFee.isNotBlank()) "غرامة يومية قدرها (${data.dailyDelayFee} د.ع)" else "غرامة يومية متفق عليها"
        val taxOwnerText = if (data.propertyTaxOwner.isNotBlank()) data.propertyTaxOwner else "المؤجر"

        val clauses = listOf(
            Pair("ثانياً", "عند ختام مدة الإيجار فإن المستأجر ملزم بتخلية المأجور وتسليمه إلى المؤجر خالياً من الشواغل."),
            Pair("ثالثاً", "إذا تأخر المستأجر عن التخلية يكون ملزماً بأن يدفع عن كل يوم تأخير $delayFeeText من غير إنذار."),
            Pair("رابعاً", "ضريبة الأملاك تقع على $taxOwnerText، أما رسوم الماء والكهرباء والتنظيفات فعلى المستأجر يدفعها منتظماً."),
            Pair("خامساً", "للمستأجر حق السكن والانتفاع بالمأجور طيلة مدة الإيجار المحررة بالكامل والتزام بالمحافظة على العين."),
            Pair("سادساً", "فقرات إضافية: ${data.additionalClauses.ifEmpty { "كتب العقد على نسختين بيد كل من الفريقين نسخة واحدة بالتراضي." }}")
        )

        val clauseBoxHeight = 52f
        val clauseBoxBg = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val clauseBoxBorder = Paint().apply {
            color = borderGray
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        val tagBgPaint = Paint().apply {
            color = Color.parseColor("#F1F5F9")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val tagTextPaint = Paint().apply {
            color = darkText
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val clauseTextPaint = Paint().apply {
            color = darkText
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        for (clause in clauses) {
            val cRect = RectF(margin, clauseY, A4_WIDTH - margin, clauseY + clauseBoxHeight)
            canvas.drawRoundRect(cRect, 8f, 8f, clauseBoxBg)
            canvas.drawRoundRect(cRect, 8f, 8f, clauseBoxBorder)

            val tagRect = RectF(A4_WIDTH - margin - 80f, clauseY + 6f, A4_WIDTH - margin - 6f, clauseY + clauseBoxHeight - 6f)
            canvas.drawRoundRect(tagRect, 6f, 6f, tagBgPaint)
            canvas.drawText(clause.first, tagRect.centerX(), clauseY + 32f, tagTextPaint)

            drawRtlText(
                canvas = canvas,
                text = clause.second,
                x = A4_WIDTH - margin - 95f,
                y = clauseY + 32f,
                maxWidth = fullWidth - 110f,
                paint = clauseTextPaint,
                align = Paint.Align.RIGHT
            )

            clauseY += clauseBoxHeight + 8f
        }

        // تاريخ التحرير
        clauseY += 10f
        val dateLineText = "حرر بتاريخ :  ${data.signDate}  كتابةً"
        val greenDatePaint = Paint().apply {
            color = greenPrimary
            textSize = 19f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText(dateLineText, A4_WIDTH - margin, clauseY, greenDatePaint)

        // ==================== 7. مربع بصمات الأختام ====================
        val stampY = clauseY + 20f
        val stampHeight = 110f
        val stampWidth = (fullWidth - 30f) / 3f

        val stampBoxPaint = Paint().apply {
            color = Color.parseColor("#FAFAFA")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val stampBorderPaint = Paint().apply {
            color = borderGray
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
            pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
            isAntiAlias = true
        }
        val stampTextPaint = Paint().apply {
            color = darkText
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val rightStamp = RectF(A4_WIDTH - margin - stampWidth, stampY, A4_WIDTH - margin, stampY + stampHeight)
        val middleStamp = RectF(A4_WIDTH - margin - (stampWidth * 2) - 15f, stampY, A4_WIDTH - margin - stampWidth - 15f, stampY + stampHeight)
        val leftStamp = RectF(margin, stampY, margin + stampWidth, stampY + stampHeight)

        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(rightStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة ابهام المؤجر", rightStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(middleStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("ختم المكتب وتوقيع المنظم", middleStamp.centerX(), stampY + 65f, stampTextPaint)

        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBoxPaint)
        canvas.drawRoundRect(leftStamp, 8f, 8f, stampBorderPaint)
        canvas.drawText("بصمة ابهام المستأجر", leftStamp.centerX(), stampY + 65f, stampTextPaint)

        // ==================== 8. صف التواقيع أسفل العقد ====================
        val w1 = if (data.witness1Name.isNotBlank()) "الشاهد: ${data.witness1Name}" else "الشاهد الأول"
        val w2 = if (data.witness2Name.isNotBlank()) "الشاهد: ${data.witness2Name}" else "الشاهد الثاني"
        drawSignatures(
            canvas = canvas,
            titles = listOf("الطرف الأول (المؤجر)", w1, w2, "الطرف الثاني (المستأجر)"),
            bottomY = A4_HEIGHT - 185f
        )
    }
}

