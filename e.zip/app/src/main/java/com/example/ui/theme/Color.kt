package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// الهوية البصرية الفاخرة للعقود (Royal Blue, Emerald, Amber & Pristine Light)
val RoyalBlue600 = Color(0xFF2563EB)
val RoyalBlue700 = Color(0xFF1D4ED8)
val RoyalBlue800 = Color(0xFF1E40AF)
val RoyalBlue900 = Color(0xFF1E3A8A)
val RoyalBlue50  = Color(0xFFEFF6FF)
val RoyalBlue100 = Color(0xFFDBEAFE)

val Emerald600   = Color(0xFF10B981)
val Emerald700   = Color(0xFF047857)
val Emerald50    = Color(0xFFECFDF5)
val Emerald100   = Color(0xD1D1FAF0)

val Amber500     = Color(0xFFF59E0B)
val Amber600     = Color(0xFFD97706)
val Amber50      = Color(0xFFFFFBEB)

val Slate900     = Color(0xFF0F172A)
val Slate800     = Color(0xFF1E293B)
val Slate700     = Color(0xFF334155)
val Slate600     = Color(0xFF475569)
val Slate500     = Color(0xFF64748B)
val Slate400     = Color(0xFF94A3B8)
val Slate200     = Color(0xFFE2E8F0)
val Slate100     = Color(0xFFF1F5F9)
val OffWhite     = Color(0xFFF8FAFC)


